﻿#include <iostream>
#include <fstream>
#include <vector>
#include <windows.h>

using namespace std;

class BMPImage {
private:
    BITMAPFILEHEADER fileHeader;
    BITMAPINFOHEADER infoHeader;
    vector<uint8_t> pixelData;  // необработанные данные пикселей
    int width;
    int height;
    int bitDepth;

public:
    BMPImage() : width(0), height(0), bitDepth(0) {}

    bool openBMP(const string& fileName) {
        ifstream file(fileName, ios::binary);

        if (!file.is_open()) {
            cerr << "Can't open file" << endl;
            return false;
        }

        // Чтение заголовков BMP
        file.read(reinterpret_cast<char*>(&fileHeader), sizeof(BITMAPFILEHEADER));
        file.read(reinterpret_cast<char*>(&infoHeader), sizeof(BITMAPINFOHEADER));

        // Проверяем, что файл является BMP и имеет корректный формат
        if (fileHeader.bfType != 0x4D42) {
            cerr << "File isn't BMP." << endl;
            file.close();
            return false;
        }

        // Поддерживаются только 24-битные или 32-битные изображения
        bitDepth = infoHeader.biBitCount;
        if (bitDepth != 24 && bitDepth != 32) {
            cerr << "Error: Only 24-bit or 32-bit BMPs are supported." << endl;
            file.close();
            return false;
        }

        // Размеры изображения
        width = infoHeader.biWidth;
        height = infoHeader.biHeight;

        // Переходим к началу данных пикселей
        file.seekg(fileHeader.bfOffBits, ios::beg);

        // Чтение данных пикселей
        int rowSize = ((bitDepth * width + 31) / 32) * 4;  // Учесть выравнивание по 4 байта
        int dataSize = rowSize * abs(height);
        pixelData.resize(dataSize);

        file.read(reinterpret_cast<char*>(pixelData.data()), dataSize);

        file.close();
        return true;
    }

    void displayBMP() {
        if (pixelData.empty()) {
            cerr << "File is not loaded" << endl;
            return;
        }

        int rowSize = ((bitDepth * width + 31) / 32) * 4;  // Размер строки с учетом выравнивания
        bool isTopDown = (infoHeader.biHeight < 0);        // Проверка направления изображение

        for (int y = 0; y < abs(height); ++y) {
            int rowIndex = isTopDown ? y : abs(height) - 1 - y;
            for (int x = 0; x < width; ++x) {
                uint8_t* pixelPtr = &pixelData[rowIndex * rowSize + x * (bitDepth / 8)];

                uint8_t blue = pixelPtr[0];
                uint8_t green = pixelPtr[1];
                uint8_t red = pixelPtr[2];

                // Вывод символов в зависимости от цвета пикселя
                if (red == 255 && green == 255 && blue == 255) {
                    cout << " ";  // Белый цвет — пробел
                }
                else if (red == 0 && green == 0 && blue == 0) {
                    cout << "#";  // Черный цвет — символ #
                }
                else {
                    cerr << "There are other colors" << endl;
                    return;
                }
            }
            cout << endl;  // Переход на новую строку после каждой строки пикселей
        }
    }

    void closeBMP() {
        // Освобождение ресурсов
        pixelData.clear();
    }

    ~BMPImage() {
        closeBMP();
    }
};

int main(int argc, char* argv[]) {
    if (argc != 2) {
        cerr << "Usage: Your exe <dir to BMP>" << endl;
        return 1;
    }

    string fileName = argv[1];
    BMPImage bmp;

    if (bmp.openBMP(fileName)) {
        bmp.displayBMP();
    }

    bmp.closeBMP();
    return 0;
}
